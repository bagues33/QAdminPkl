<div class="alert alert-<?php echo e($type); ?>">
	<?php echo e($message); ?>

</div><?php /**PATH /Applications/MAMP/htdocs/QAdminPkl/resources/views/components/alert.blade.php ENDPATH**/ ?>