<div class="col-xl-<?php echo e(($size) ?? '3'); ?> col-md-6 mb-4">
    <div class="card h-100">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo e($text); ?></div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($value); ?></div>
                    
                </div>
                <div class="col-auto">
                    <a href="<?php echo e($url1); ?>" class="info" data-nama="<?php echo e($namaTim); ?>" data-deskripsi="<?php echo e($deskripsi); ?>" data-anggota="<?php echo e($anggota); ?>" href="<?php echo e($url1); ?>"><i class="fas fa-<?php echo e($icon1); ?> fa-2x text-<?php echo e(($color1) ?? 'primary'); ?>"></i></a>
                    <a href="<?php echo e($url2); ?>"><i class="fas fa-<?php echo e($icon2); ?> fa-2x text-<?php echo e(($color2) ?? 'primary'); ?>"></i></a>
                    <form action="<?php echo e($url3); ?>" style="display: inline-block;" method="POST">
                        <?php echo csrf_field(); ?>
                        <a href="#" class="delete"><i class="fas fa-trash"></i></a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH /Applications/MAMP/htdocs/QAdminPkl/resources/views/components/card-tim.blade.php ENDPATH**/ ?>