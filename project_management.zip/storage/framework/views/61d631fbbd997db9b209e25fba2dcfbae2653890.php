<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Laporan Daftar Tim Per Project</title>
    <style>
        .line {
            height: 2px !important;
            background-color: black !important;
            color: black !important;
        }
    </style>
  </head>
  <body onload="window.print()">
    


    <div class="container mt-3">
        <div class="row">
            <div class="col-2">
                <img class="img-fluid" src="<?php echo e(asset('dist/img/logo-picsi-2.png')); ?>" alt="">
            </div>
            <div class="col-10">
                <h4>PT. PILAR CIPTA SOLUSI INTEGRATIKA</h4>
                <p>Klitren, Kec. Gondokusuman, Kota Yogyakarta, Daerah Istimewa Yogyakarta 55222</p>
            </div>
            <div class="line">
            </div>
        </div>
        
       
        <div class="row">
            <h3 class="text-center mt-5 mb-5">Laporan Per Project</h3>
            <table class="table table-borderless">
                <thead>
                </thead>
                <tbody>
                    
                    <tr>
                        <td>Nama Project</td>
                        <td>:</td>
                        <td id="nama-project"><?php echo e($project->nama); ?></td>
                    </tr>
                    <tr>
                        <td>Nama Klien</td>
                        <td>:</td>
                        <td id="nama-klien"><?php echo e($project->klien->nama); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Mulai</td>
                        <td>:</td>
                        <td id="tgl-mulai"><?php echo e($project->tgl_mulai); ?></td>
                    </tr>
                    <tr>
                        <td>Deadline</td>
                        <td>:</td>
                        <td id="deadline"><?php echo e($project->deadline); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Selesai</td>
                        <td>:</td>
                        <td id="tgl-selesai"><?php echo e($project->tgl_selesai ? $project->tgl_selesai : "Belum selesai"); ?></td>
                    </tr>
                    <tr>
                        <td>Budget</td>
                        <td>:</td>
                        <td id="budget"><?php echo e($project->budget); ?></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td>:</td>
                        <td id="status"><?php echo e($project->status); ?></td>
                    </tr>
                    <tr>
                        <td>Project Manager</td>
                        <td>:</td>
                        <td id="pm"><?php echo e($project->user->name); ?></td>
                    </tr>
                    <tr>
                        <td>Jumlah Tenaga Ahli</td>
                        <td>:</td>
                        <td id="tenaga-ahli">
                            <?php $__empty_1 = true; $__currentLoopData = $project->tim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo e(count($tim->anggota)); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php echo e(0); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Deskripsi</td>
                        <td>:</td>
                        <td id="deskripsi"><?php echo e($project->deskripsi); ?></td>
                    </tr>
                 
                </tbody>
            </table>
        </div>
        <div class="row">
            <div class="d-flex justify-content-end mt-5">
                <div class="text-center" style="width: 200px;">
                    <p>Yogyakarta, <?php echo e(date('d-m-Y')); ?></p>
                    <p>Mengetahui</p>
                    <br><br><br>
                    <p>( <?php echo e($user->name); ?> )</p>
                </div>
            </div>
        </div>
        
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/QAdminPkl/resources/views/laporan/daftarproject/laporanperprojectprint.blade.php ENDPATH**/ ?>