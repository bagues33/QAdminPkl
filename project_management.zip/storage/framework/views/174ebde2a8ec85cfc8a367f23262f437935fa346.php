

 <h3><?php echo e($data['title']); ?></h3>
 <h4><?php echo e($data['url']); ?></h4><?php /**PATH /Applications/MAMP/htdocs/QAdminPkl/resources/views/emails/notifikasi.blade.php ENDPATH**/ ?>