<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title'); ?> Task <?php $__env->endSlot(); ?>

	<?php if(session()->has('success')): ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => 'success','message' => ''.e(session()->get('success')).'']]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'success','message' => ''.e(session()->get('success')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	<?php endif; ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title'); ?> All Task <?php $__env->endSlot(); ?>
		 <?php $__env->slot('option'); ?> 

		 <?php $__env->endSlot(); ?>
		 <?php $__env->endSlot(); ?>
		<table class="table table-bordered">
			<thead>
				<th>Nama Project Manager</th>
				<th>Nama Task</th>
				<!-- <th>Deskripsi</th> -->
                <th>Type</th>
                <th>Prioritas</th>
				<th>Status</th>
				<th>Approved</th>
			</thead>
			<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<tr>
					<td><?php echo e($task->anggota->getPm->name); ?></td>
					<td><?php echo e($task->nama); ?></td>
					<!-- <td><?php echo e($task->deskripsi); ?></td> -->
                    <td><?php echo e($task->type); ?></td>
                    <td><?php echo e($task->prioritas); ?></td>
					<td>
						<?php if($task->status == 'notstarted'): ?>
							<span class="badge bg-primary text-white">Not Started</span>
						<?php elseif($task->status == 'inprogress'): ?>
							<span class="badge bg-warning text-white">In Progress</span>
						<?php elseif($task->status == 'done'): ?>
							<span class="badge bg-success text-white">Done</span>
						<?php elseif($task->status == 'cancel'): ?>
							<span class="badge bg-danger text-white">Cancel</span>
						<?php endif; ?>
					</td>
					<td class="text-center">
						<?php if($task->approved): ?>
							<span class="badge bg-success text-white"><i class="fas fa-check"></i></span>
						<?php else: ?>
							<span class="badge bg-danger text-white"><i class="fa fa-times" aria-hidden="true"></i></span>
						<?php endif; ?>
					</td>
					<td class="text-center">
						<button type="button" class="btn btn-info mr-1 info" data-pm="<?php echo e($task->anggota->getPm->name); ?>"
						data-nama="<?php echo e($task->nama); ?>" data-deskripsi="<?php echo e($task->deskripsi); ?>" data-type="<?php echo e($task->type); ?>" data-prioritas="<?php echo e($task->prioritas); ?>" data-status="
						<?php if($task->status == 'notstarted'): ?>
							<span class='badge bg-primary text-white'>Not Started</span> 
						<?php elseif($task->status == 'inprogress'): ?>
							<span class='badge bg-warning text-white'>In Progress</span>
						<?php elseif($task->status == 'done'): ?>
							<span class='badge bg-success text-white'>Done</span>
						<?php elseif($task->status == 'cancel'): ?>
							<span class='badge bg-danger text-white'>Cancel</span>
						<?php endif; ?>
						" 
						data-approved="
						<?php if($task->approved): ?>
							<span class='badge bg-success text-white'><i class='fas fa-check'></i></span>
						<?php else: ?>
							<span class='badge bg-danger text-white'><i class='fa fa-times' aria-hidden='true'></i></span>
						<?php endif; ?>
						"
						data-submittask="<?php if($task->submit_task): ?> <?php echo e($task->submit_task); ?> <?php else: ?> Belum submit task! <?php endif; ?>">
							<i class="fas fa-eye"></i>
						</button>
						<a href="<?php echo e(route('anggota.task.create', $task->id_task)); ?>" class="btn btn-success">
							<i class="fas fa-plus"></i>
						</a>
						<a href="<?php echo e(route('anggota.komentar', $task->id_task)); ?>" class="btn btn-warning">
							<i class="fas fa-comments"></i>
						</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<tr>
					<td colspan="5" class="text-center">No Data</td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('id'); ?> infoModal <?php $__env->endSlot(); ?>
		 <?php $__env->slot('title'); ?> Information <?php $__env->endSlot(); ?>

		<div class="row mb-2">
			<div class="col-6">
				<b>Nama Project Manager</b>
			</div>
			<div class="col-6" id="pm-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Nama Task</b>
			</div>
			<div class="col-6" id="nama-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Deskripsi</b>
			</div>
			<div class="col-6" id="deskripsi-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Type</b>
			</div>
			<div class="col-6" id="type-modal"></div>
		</div>
		
		<div class="row mb-2">
			<div class="col-6">
				<b>Prioritas</b>
			</div>
			<div class="col-6" id="prioritas-modal"></div>
		</div>
		<hr>
		<div class="row mb-2">
			<div class="col-6">
				<b>Status</b>
			</div>
			<div class="col-6" id="status-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Approved</b>
			</div>
			<div class="col-6" id="approved-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Submit Task</b>
			</div>
			<div class="col-6" id="submittask-modal"></div>
		</div>
		
	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

	 <?php $__env->slot('script'); ?> 
		<script>
			$('.info').click(function(e) {
				e.preventDefault()

				$('#pm-modal').text($(this).data('pm'))
				$('#nama-modal').text($(this).data('nama'))
				$('#deskripsi-modal').text($(this).data('deskripsi'))
				$('#type-modal').text($(this).data('type'))
				$('#prioritas-modal').text($(this).data('prioritas'))
				$('#status-modal').html($(this).data('status'))
				$('#approved-modal').html($(this).data('approved'))
				$('#submittask-modal').text($(this).data('submittask'))
				$('#infoModal').modal('show')
			})

			$('.delete').click(function(e){
				e.preventDefault()
				const ok = confirm('Ingin menghapus user?')

				if(ok) {
					$(this).parent().submit()
				}
			})
		</script>
	 <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Applications/MAMP/htdocs/QAdminPkl/resources/views/anggota/index.blade.php ENDPATH**/ ?>