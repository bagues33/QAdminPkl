<meta name="twitter:card" content="summary_large_image" />
<meta property="og:type" content="website">
<meta property="og:title" content="{{ $title }}" />
<meta name="description" content="{{ $description }}">
<meta property="og:description" content="Blade components are awesome!">
<meta property="og:image" content="{{ $image }}" />
<meta property="og:url" content="{{ Request::url() }}" />
<meta property="og:locale" content="en" />