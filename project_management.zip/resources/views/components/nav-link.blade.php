<li class="nav-item{{ $active }}">
    <a class="nav-link" href="{{ $url }}">
        <i class="fas fa-fw fa-{{ $icon }}"></i>
        <span>{{ $text }}</span>
    </a>
</li>