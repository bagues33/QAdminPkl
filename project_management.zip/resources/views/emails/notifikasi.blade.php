{{-- <h3>Halo, {{ $nama }} !</h3> --}}
{{-- <p>{{ $website }}</p> --}}
 <h3>{{ $data['title'] }}</h3>
 <h4>{{ $data['url'] }}</h4>