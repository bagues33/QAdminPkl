<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title'); ?> Laporan per Project <?php $__env->endSlot(); ?>

	<?php if(session()->has('success')): ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => 'success','message' => ''.e(session()->get('success')).'']]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'success','message' => ''.e(session()->get('success')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	<?php endif; ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		
         <?php $__env->slot('option'); ?> 
			<a id="print" href="#" class="btn btn-secondary">
				<i class="fas fa-print"></i>
			</a>
		 <?php $__env->endSlot(); ?>
		<Label for="">Pilih Tahun</Label>
        <select id="select_tahun" class="form-control" aria-label="Default select example">
            <option value="0">Pilih Tahun</option>
            <?php $__currentLoopData = $list_tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($list->year); ?>"><?php echo e($list->year); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
		<Label for="">Pilih Project</Label>
        <select id="select_project" class="form-control" aria-label="Default select example">
            <option value="0">Pilih Project</option>
            <?php $__currentLoopData = $list_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($list->id_project); ?>"><?php echo e($list->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
		<br>
        <div class="table-responsive">
		<table class="table table-borderless">
			<thead>
			</thead>
			<tbody>
				
				<tr>
					<td>Nama Project</td>
                    <td>:</td>
                    <td id="nama-project">
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php echo e($project->nama); ?>

						<?php endif; ?>
					</td>
				</tr>
                <tr>
					<td>Nama Klien</td>
                    <td>:</td>
                    <td id="nama-klien">
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php echo e($project->klien->nama); ?>

						<?php endif; ?>
					</td>
				</tr>
                <tr>
					<td>Tanggal Mulai</td>
                    <td>:</td>
                    <td id="tgl-mulai">
						
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php echo e($project->tgl_mulai); ?>

						<?php endif; ?>
					</td>
				</tr>
                <tr>
					<td>Deadline</td>
                    <td>:</td>
                    <td id="deadline">
						
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php echo e($project->deadline); ?>

						<?php endif; ?>
					</td>
				</tr>
                <tr>
					<td>Tanggal Selesai</td>
                    <td>:</td>
                    <td id="tgl-selesai">
						
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php echo e($project->tgl_selesai); ?>

						<?php endif; ?>
					</td>
				</tr>
                <tr>
					<td>Budget</td>
                    <td>:</td>
                    <td id="budget">
						
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php echo e($project->budget); ?>

						<?php endif; ?>
					</td>
				</tr>
                <tr>
					<td>Status</td>
                    <td>:</td>
                    <td id="status">
						
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php echo e($project->status); ?>

						<?php endif; ?>
					</td>
				</tr>
                <tr>
					<td>Project Manager</td>
                    <td>:</td>
                    <td id="pm">
						
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php echo e($project->user->name); ?>

						<?php endif; ?>
					</td>
				</tr>
                <tr>
					<td>Tenaga Ahli</td>
                    <td>:</td>
                    <td id="tenaga-ahli">
						
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php $__currentLoopData = $project->tim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php echo e(count($tim->anggota)); ?>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</td>
				</tr>
                <tr>
					<td>Deskripsi</td>
                    <td>:</td>
                    <td id="deskripsi">
						
						<?php if(empty($project)): ?>
							Data tidak tersedia
						<?php else: ?>
							<?php echo e($project->deskripsi); ?>

						<?php endif; ?>
					</td>
				</tr>
				
				
				
			</tbody>
		</table>
        </div>
	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('id'); ?> infoModal <?php $__env->endSlot(); ?>
		 <?php $__env->slot('title'); ?> Information <?php $__env->endSlot(); ?>

		<div class="row mb-2">
			<div class="col-6">
				<b>Deskripsi</b>
			</div>
			<div class="col-6" id="deskripsi-modal"></div>
		</div>
	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

	 <?php $__env->slot('script'); ?> 
		<script>

			$(document).ready(function(){

			// Department Change
			$('#select_project').change(function(){

				// Department id
				var id = $(this).val();
				// console.log(id);

				// AJAX request 
				$.ajax({
					url: 'datatimperproject/' + id,
					type: 'get',
					dataType: 'json',
					success: function(response){
						console.log(response);
						var trHTML = '';
						var no = 0;
						$.each(response, function (key,value) {
							// console.log(value.nama);
							$('#nama-project').text(value.nama);
							$('#nama-klien').text(value.klien.nama);
							$('#tgl-mulai').text(value.tgl_mulai);
							$('#deadline').text(value.deadline);
							$('#tgl-selesai').text(value.tgl_selesai ? value.tgl_selesai : "Belum selesai");
							$('#budget').text(value.budget);
							$('#status').text(value.status);
							$('#pm').text(value.user.name);
							if(value.tim.length) {
								$.each(value.tim, function (key,value) {
									$('#tenaga-ahli').text(value.anggota.length);
								});	
							} else {
								$('#tenaga-ahli').text(0);
							}
							$('#deskripsi').text(value.deskripsi);
						});
					}
				});
			});

			$('#select_tahun').change(function(){

				// Department id
				var id = $(this).val();
				// console.log(id);
				$('#select_project').find('option').not(':first').remove();
				// AJAX request 
				$.ajax({
				url: 'getlistproject/' + id,
				type: 'get',
				dataType: 'json',
				success: function(response){
					// console.log(response);
					var trHTML = '';
					var no = 0;
					$.each(response, function (key,value) {
						// console.log(value.nama);
						var option = "<option value='"+value.id_project+"'>"+value.nama+"</option>"; 

                		 $("#select_project").append(option); 
					});
				}
				});
			});

			});

			$('#print').click(function(e){
				e.preventDefault()

               var pilih_project = $("#select_project option:selected").val();

                // console.log(pilih_project);
                window.location.href = "laporanperprojectprint/" + pilih_project;
				
			})


			$('.info').click(function(e) {
				e.preventDefault()

				$('#nama-modal').text($(this).data('name'))
				$('#notelpon-modal').text($(this).data('notelpon'))
				$('#alamat-modal').text($(this).data('alamat'))
				$('#email-modal').text($(this).data('email'))
				$('#photo-modal').attr('src', $(this).data('photo'))
				$('#website-modal').text($(this).data('website'))
				$('#deskripsi-modal').text($(this).data('deskripsi'))

				$('#infoModal').modal('show')
			})

			$('.delete').click(function(e){
				e.preventDefault()
				const ok = confirm('Ingin menghapus user?')

				if(ok) {
					$(this).parent().submit()
				}
			})
		</script>
	 <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Applications/MAMP/htdocs/QAdminPkl/resources/views/laporan/daftarproject/laporanperproject.blade.php ENDPATH**/ ?>