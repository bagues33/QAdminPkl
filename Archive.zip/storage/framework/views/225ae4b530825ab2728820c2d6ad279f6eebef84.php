<div class="alert alert-<?php echo e($type); ?>">
	<?php echo e($message); ?>

</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/QAdminPkl/resources/views/components/alert.blade.php ENDPATH**/ ?>