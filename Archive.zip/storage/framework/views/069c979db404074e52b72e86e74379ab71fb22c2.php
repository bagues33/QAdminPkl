<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title'); ?> Laporan Daftar Tim per Project <?php $__env->endSlot(); ?>

	<?php if(session()->has('success')): ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => 'success','message' => ''.e(session()->get('success')).'']]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'success','message' => ''.e(session()->get('success')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	<?php endif; ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		
         <?php $__env->slot('option'); ?> 
			
            <a id="print" href="#" class="btn btn-secondary">
				<i class="fas fa-print"></i>
			</a>
		 <?php $__env->endSlot(); ?>
        <Label for="">Pilih Project</Label>
        <select id="select_project" class="form-control" aria-label="Default select example">
            <option value="0">Pilih Project</option>
            <?php $__currentLoopData = $list_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($list->id_project); ?>"><?php echo e($list->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if(empty($projects)): ?>
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
            <h5 id="nama_project" class="mt-4"><?php echo e($project->nama); ?></h5>
            <div class="table-responsive mt-4">
                <table id="data_tim" class="table table-bordered">
                    <thead>
                        <th>No</th>
                        <th>Nama Tim</th>
                        <th>Deskripsi</th>
                        <th>Jumlah Anggota</th>
                    </thead>
                    <tbody>
                        <?php $__empty_2 = true; $__currentLoopData = $project->tim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <tr class="data-row">
                            <td><?php echo e(++$no); ?></td>
                            <td><?php echo e($tim->nama); ?></td>
                            <td><?php echo e($tim->deskripsi); ?></td>
                            <td>
                                <?php echo e(count($tim->anggota)); ?>

                            </td>
                            
                                
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?> 
                        <tr>
                            <td colspan="4" class="text-center">No data</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        <?php else: ?>
            <h5 id="nama_project" class="mt-4"></h5>
            <div class="table-responsive mt-4">
                <table id="data_tim" class="table table-bordered">
                    <thead>
                        <th>No</th>
                        <th>Nama Tim</th>
                        <th>Deskripsi</th>
                        <th>Jumlah Anggota</th>
                    </thead>
                    <tbody>
                        
                        <tr class="data-row">
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>
                                
                            </td>
                            
                                
                            
                        </tr>
                        
                        <tr>
                            <td id="no-data" colspan="4" class="text-center">No data</td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    
	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('id'); ?> infoModal <?php $__env->endSlot(); ?>
		 <?php $__env->slot('title'); ?> Information <?php $__env->endSlot(); ?>

		<div class="row mb-2">
			<div class="col-6">
				<b>Nama</b>
			</div>
			<div class="col-6" id="nama-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>No Telpon</b>
			</div>
			<div class="col-6" id="notelpon-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Alamat</b>
			</div>
			<div class="col-6" id="alamat-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Email</b>
			</div>
			<div class="col-6" id="email-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Photo</b>
			</div>
			<div class="col-6"><img id="photo-modal" class="img-fluid" src="#"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Website</b>
			</div>
			<div class="col-6" id="website-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Deskripsi</b>
			</div>
			<div class="col-6" id="deskripsi-modal"></div>
		</div>
	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

	 <?php $__env->slot('script'); ?> 
		<script>

            $(document).ready(function(){

                // Department Change
                $('#select_project').change(function(){

                    // Department id
                    var id = $(this).val();
                    // console.log(id);

                    // AJAX request 
                    $.ajax({
                        url: 'datatimperproject/' + id,
                        type: 'get',
                        dataType: 'json',
                        success: function(response){
                            console.log(response);
                            var trHTML = '';
                            var no = 0;
                            $.each(response, function (key,value) {
                                $("#nama_project").text(function (index, text) {
                                    return text.replace(text, value.nama);
                                });
                                // console.log(value.nama);
                                if(value.tim.length) {
                                    $.each(value.tim, function (key,value) {
                                    trHTML += 
                                    '<tr class="data-row"><td>' + ++no + 
                                    '</td><td>' + value.nama + 
                                    '</td><td>' + value.deskripsi + 
                                    '</td><td>' + value.anggota.length + 
                                    '</td></tr>';    
                                     }) 
                                    //  console.log("data")
                                } else {
                                    trHTML += '<tr class="data-row"><td class="text-center" colspan="4">No data</td></tr>'
                                    // console.log("no data")
                                }
                            });
                            $('.data-row').remove();
                            $('#no-data').remove();
                            $('#data_tim').append(trHTML);
                        }
                    });
                });
            });

            $('#print').click(function(e){
				e.preventDefault()

               var pilih_project = $("#select_project option:selected").val();

                // console.log(pilih_project);
                window.location.href = "timperprojectprint/" + pilih_project;
				
			})

			$('.info').click(function(e) {
				e.preventDefault()

				$('#nama-modal').text($(this).data('name'))
				$('#notelpon-modal').text($(this).data('notelpon'))
				$('#alamat-modal').text($(this).data('alamat'))
				$('#email-modal').text($(this).data('email'))
				$('#photo-modal').attr('src', $(this).data('photo'))
				$('#website-modal').text($(this).data('website'))
				$('#deskripsi-modal').text($(this).data('deskripsi'))

				$('#infoModal').modal('show')
			})

			$('.delete').click(function(e){
				e.preventDefault()
				const ok = confirm('Ingin menghapus user?')

				if(ok) {
					$(this).parent().submit()
				}
			})
		</script>
	 <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Applications/MAMP/htdocs/QAdminPkl/resources/views/laporan/daftartim/daftartimperproject.blade.php ENDPATH**/ ?>