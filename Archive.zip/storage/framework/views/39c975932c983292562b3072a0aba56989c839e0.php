<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title'); ?> Task for Anggota <?php $__env->endSlot(); ?>

	<?php if(session()->has('success')): ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => 'success','message' => ''.e(session()->get('success')).'']]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'success','message' => ''.e(session()->get('success')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	<?php endif; ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title'); ?> All Task <?php $__env->endSlot(); ?>
		 <?php $__env->slot('option'); ?> 
			<a href="<?php echo e(route('pm.task.create')); ?>" class="btn btn-success">
				<i class="fas fa-plus"></i>
			</a>
		 <?php $__env->endSlot(); ?>
		<form class="navbar-search d-flex" action="<?php echo e(route('pm.task.search')); ?>" method="GET">
			<div class="input-group">
				<input type="text" name="search" class="form-control bg-light border-1 small" placeholder="Silahkan ketik kata pencarian..."
					aria-label="Search" aria-describedby="basic-addon2" style="border-color: #3f51b5;">
				<div class="input-group-append">
					<button class="btn btn-primary" type="submit">
						<i class="fas fa-search fa-sm"></i>
					</button>
				</div>
			</div>
			<a href="<?php echo e(route('pm.task')); ?>">
				<button class="btn btn-success ml-3" type="button">
					<i class="fas fa-sync"></i>
				</button>
			</a>
		</form>
		<table class="table table-bordered mt-4">
			<thead>
				<th>Nama</th>
				<th>Prioritas</th>
				<th>Deadline</th>
				<th>Nama Anggota</th>
				<th>Status</th>
				<th>Approved</th>
			</thead>
			<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<tr>
					<td><?php echo e($task->nama); ?></td>
					<td><?php echo e($task->prioritas); ?></td>
					<td><?php echo e($task->deadline); ?></td>
					<td><?php echo e($task->anggota->user->name); ?></td>
					<td>
						<?php if($task->status == 'notstarted'): ?>
							<span class="badge bg-primary text-white">Not Started</span>
						<?php elseif($task->status == 'inprogress'): ?>
							<span class="badge bg-warning text-white">In Progress</span>
						<?php elseif($task->status == 'done'): ?>
							<span class="badge bg-success text-white">Done</span>
						<?php elseif($task->status == 'cancel'): ?>
							<span class="badge bg-danger text-white">Cancel</span>
						<?php endif; ?>
					</td>
					<td class="text-center">
						<?php if($task->approved): ?>
							<span class="badge bg-success text-white"><i class="fas fa-check"></i></span>
						<?php else: ?>
							<span class="badge bg-danger text-white"><i class="fa fa-times" aria-hidden="true"></i></span>
						<?php endif; ?>
					</td>
					<td class="text-center">
						<button type="button" class="btn btn-info mr-1 info"
						data-nama="<?php echo e($task->nama); ?>" data-deskripsi="<?php echo e($task->deskripsi); ?>" data-type="<?php echo e($task->type); ?>" data-prioritas="<?php echo e($task->prioritas); ?>" data-anggota="<?php echo e($task->anggota->user->name); ?>" data-deadline="<?php echo e($task->deadline); ?>" data-status="
						<?php if($task->status == 'notstarted'): ?>
							<span class='badge bg-primary text-white'>Not Started</span> 
						<?php elseif($task->status == 'inprogress'): ?>
							<span class='badge bg-warning text-white'>In Progress</span>
						<?php elseif($task->status == 'done'): ?>
							<span class='badge bg-success text-white'>Done</span>
						<?php elseif($task->status == 'cancel'): ?>
							<span class='badge bg-danger text-white'>Cancel</span>
						<?php endif; ?>
						" data-submittask=" <?php if($task->submit_task): ?> <?php echo e($task->submit_task); ?> <?php else: ?> Submit task belum ada! <?php endif; ?>">
							<i class="fas fa-eye"></i>
						</button>
						<!-- <a href="<?php echo e(route('pm.task.show', $task->id_task)); ?>" class="btn btn-primary mr-1"><i class="fas fa-eye"></i></a>  -->
						<a href="<?php echo e(route('pm.task.edit', $task->id_task)); ?>" class="btn btn-primary mr-1"><i class="fas fa-edit"></i></a> 
						
						<form action="<?php echo e(route('pm.task.delete', $task->id_task)); ?>" style="display: inline-block;" method="POST">
							<?php echo csrf_field(); ?>
							<button type="button" class="btn btn-danger delete"><i class="fas fa-trash"></i></button>
						</form>
						<a href="<?php echo e(route('pm.komentar', $task->id_task)); ?>" class="btn btn-warning">
							<i class="fas fa-comments"></i>
						</a>
						<a target="_blank" href="https://wa.me/62<?php echo e(ltrim($task->anggota->user->no_hp, '0')); ?>/?text=*PEMBERITAHUAN!!!*%0aNama Task : <?php echo e($task->nama); ?>%0aDeskripsi : <?php echo e($task->deskripsi); ?>%0aType : <?php echo e($task->type); ?>%0aPrioritas : <?php echo e($task->prioritas); ?>%0aDeadline : <?php echo e($task->deadline); ?>%0aNama Anggota : <?php echo e($task->anggota->user->name); ?>%0aStatus Task : <?php echo e($task->status); ?>" class="btn btn-success">
							<i class="fab fa-whatsapp"></i>
						</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<tr>
					<td colspan="6" class="text-center">No Data</td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
		<p class="mt-3"> 
			Halaman : <?php echo e($tasks->currentPage()); ?> /
			Jumlah Data : <?php echo e($tasks->total()); ?> /
			Data Per Halaman : <?php echo e($tasks->perPage()); ?> 
		</p>
        <?php echo e($tasks->links()); ?>

	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('id'); ?> infoModal <?php $__env->endSlot(); ?>
		 <?php $__env->slot('title'); ?> Information <?php $__env->endSlot(); ?>

		<div class="row mb-2">
			<div class="col-6">
				<b>Nama</b>
			</div>
			<div class="col-6" id="nama-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Deskripsi</b>
			</div>
			<div class="col-6" id="deskripsi-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Type</b>
			</div>
			<div class="col-6" id="type-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Prioritas</b>
			</div>
			<div class="col-6" id="prioritas-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Deadline</b>
			</div>
			<div class="col-6" id="deadline-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Nama Anggota</b>
			</div>
			<div class="col-6" id="anggota-modal"></div>
		</div>
		<hr>
		<div class="row mb-2">
			<div class="col-6">
				<b>Status Task</b>
			</div>
			<div class="col-6" id="status-modal"></div>
		</div>
		<div class="row mb-2">
			<div class="col-6">
				<b>Submit Task</b>
			</div>
			<div class="col-6" id="submittask-modal"></div>
		</div>
	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

	 <?php $__env->slot('script'); ?> 
		<script>
			$('.info').click(function(e) {
				e.preventDefault()
				$('#nama-modal').text($(this).data('nama'))
				$('#deskripsi-modal').text($(this).data('deskripsi'))
				$('#type-modal').text($(this).data('type'))
				$('#prioritas-modal').text($(this).data('prioritas'))
				$('#deadline-modal').text($(this).data('deadline'))
				$('#anggota-modal').text($(this).data('anggota'))
				$('#status-modal').html($(this).data('status'))
				$('#submittask-modal').text($(this).data('submittask'))
				$('#infoModal').modal('show')
				
			})

			$('.delete').click(function(e){
				e.preventDefault()
				const ok = confirm('Ingin menghapus user?')

				if(ok) {
					$(this).parent().submit()
				}
			})

		</script>
	 <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Applications/MAMP/htdocs/QAdminPkl/resources/views/admin/task/index.blade.php ENDPATH**/ ?>