<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="">
        <div class="sidebar-brand-icon">
            <img src="<?php echo e(asset((setting('logo')) ? '/storage/'.setting('logo') : 'dist/img/logo/logo2.png')); ?>">
        </div>
        <div class="sidebar-brand-text mx-3">PT. PICSI</div>
    </a>
    <hr class="sidebar-divider my-0">

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Dashboard','icon' => 'tachometer-alt','url' => ''.e(route('dashboard')).'','active' => ''.e(request()->routeIs('dashboard') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Dashboard','icon' => 'tachometer-alt','url' => ''.e(route('dashboard')).'','active' => ''.e(request()->routeIs('dashboard') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    
    <hr class="sidebar-divider mb-0">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('klien')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Klien','icon' => 'male','url' => ''.e(route('admin.klien')).'','active' => ''.e(request()->routeIs('admin.klien') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Klien','icon' => 'male','url' => ''.e(route('admin.klien')).'','active' => ''.e(request()->routeIs('admin.klien') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <hr class="sidebar-divider mb-0">
    <?php endif; ?>    

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Projects','icon' => 'archive','url' => ''.e(route('admin.project')).'','active' => ''.e(request()->routeIs('admin.project') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Projects','icon' => 'archive','url' => ''.e(route('admin.project')).'','active' => ''.e(request()->routeIs('admin.project') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <hr class="sidebar-divider mb-0">
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tim')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Tim','icon' => 'users','url' => ''.e(route('pm.tim')).'','active' => ''.e(request()->routeIs('pm.tim') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Tim','icon' => 'users','url' => ''.e(route('pm.tim')).'','active' => ''.e(request()->routeIs('pm.tim') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <hr class="sidebar-divider mb-0">
    <?php endif; ?>

    <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Anggota','icon' => 'user','url' => ''.e(route('admin.anggota')).'','active' => ''.e(request()->routeIs('admin.anggota') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Anggota','icon' => 'user','url' => ''.e(route('admin.anggota')).'','active' => ''.e(request()->routeIs('admin.anggota') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <hr class="sidebar-divider mb-0"> -->
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-pm')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Task (PM)','icon' => 'tasks','url' => ''.e(route('pm.task')).'','active' => ''.e(request()->routeIs('pm.task.index') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Task (PM)','icon' => 'tasks','url' => ''.e(route('pm.task')).'','active' => ''.e(request()->routeIs('pm.task.index') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-anggota')): ?>
    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Task (Anggota)','icon' => 'tasks','url' => ''.e(route('anggota.task.index')).'','active' => ''.e(request()->routeIs('anggota.task') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Task (Anggota)','icon' => 'tasks','url' => ''.e(route('anggota.task.index')).'','active' => ''.e(request()->routeIs('anggota.task') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>

    

    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
        

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Laporan Daftar Klien','icon' => 'file-pdf','url' => ''.e(route('admin.laporan.klien')).'','active' => ''.e(request()->routeIs('admin.laporan.klien') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Laporan Daftar Klien','icon' => 'file-pdf','url' => ''.e(route('admin.laporan.klien')).'','active' => ''.e(request()->routeIs('admin.laporan.klien') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Laporan Rekap Pekerjaan','icon' => 'file-pdf','url' => ''.e(route('admin.laporan.rekappekerjaan')).'','active' => ''.e(request()->routeIs('admin.laporan.rekappekerjaan') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Laporan Rekap Pekerjaan','icon' => 'file-pdf','url' => ''.e(route('admin.laporan.rekappekerjaan')).'','active' => ''.e(request()->routeIs('admin.laporan.rekappekerjaan') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Laporan Per Project','icon' => 'file-pdf','url' => ''.e(route('admin.laporan.laporanperproject')).'','active' => ''.e(request()->routeIs('admin.laporan.laporanperproject') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Laporan Per Project','icon' => 'file-pdf','url' => ''.e(route('admin.laporan.laporanperproject')).'','active' => ''.e(request()->routeIs('admin.laporan.laporanperproject') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Laporan Semua Project','icon' => 'file-pdf','url' => ''.e(route('admin.laporan.daftarproject')).'','active' => ''.e(request()->routeIs('admin.laporan.daftarproject') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Laporan Semua Project','icon' => 'file-pdf','url' => ''.e(route('admin.laporan.daftarproject')).'','active' => ''.e(request()->routeIs('admin.laporan.daftarproject') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('pm')): ?>
        <hr class="sidebar-divider mb-0">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Laporan Daftar Tim Per Project','icon' => 'file-pdf','url' => ''.e(route('pm.laporan.timperproject')).'','active' => ''.e(request()->routeIs('pm.laporan.timperproject') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Laporan Daftar Tim Per Project','icon' => 'file-pdf','url' => ''.e(route('pm.laporan.timperproject')).'','active' => ''.e(request()->routeIs('pm.laporan.timperproject') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Laporan Daftar Task Per Project','icon' => 'file-pdf','url' => ''.e(route('pm.laporan.taskperproject')).'','active' => ''.e(request()->routeIs('pm.laporan.taskperproject') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Laporan Daftar Task Per Project','icon' => 'file-pdf','url' => ''.e(route('pm.laporan.taskperproject')).'','active' => ''.e(request()->routeIs('pm.laporan.taskperproject') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
   
        
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('member-list')): ?>
    <hr class="sidebar-divider mb-0">

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Member','icon' => 'users','url' => ''.e(route('admin.member')).'','active' => ''.e(request()->routeIs('admin.member') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Member','icon' => 'users','url' => ''.e(route('admin.member')).'','active' => ''.e(request()->routeIs('admin.member') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Roles','icon' => 'th-list','url' => ''.e(route('admin.roles')).'','active' => ''.e(request()->routeIs('admin.roles') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Roles','icon' => 'th-list','url' => ''.e(route('admin.roles')).'','active' => ''.e(request()->routeIs('admin.roles') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting-list')): ?>
    <hr class="sidebar-divider mb-0">

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Settings','icon' => 'cogs','url' => ''.e(route('admin.settings')).'','active' => ''.e(request()->routeIs('admin.settings') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Settings','icon' => 'cogs','url' => ''.e(route('admin.settings')).'','active' => ''.e(request()->routeIs('admin.settings') ? ' active' : '').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>
    
</ul><?php /**PATH /Applications/MAMP/htdocs/QAdminPkl/resources/views/components/sidebar.blade.php ENDPATH**/ ?>